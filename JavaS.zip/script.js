

const titulo = document.querySelector("#titulo");
const texto = document.querySelector("#texto");
const botao = document.querySelector("#botao");

console.log(titulo);
console.log(texto);
console.log(botao);



// EXERCÍCIO 2 


titulo.textContent = "Bem-vindo ao JavaScript!";
texto.textContent = "Esse texto foi alterado pelo JavaScript.";
botao.textContent = "Clicar";

// EXERCÍCIO 3 

const nome = "Maria";
const idade = 18;
const cidade = "São Leopoldo";


const elementoNome = document.querySelector("#nome");
const elementoIdade = document.querySelector("#idade");
const elementoCidade = document.querySelector("#cidade");


elementoNome.textContent = nome;
elementoIdade.textContent = idade;
elementoCidade.textContent = cidade;



// EXERCÍCIO 4 

const imagem = document.querySelector("#imagem");
const botaoImagem = document.querySelector("#botaoImagem");


botaoImagem.addEventListener("click", function() {

    imagem.setAttribute("src", "cachorro.jpeg");
    imagem.setAttribute("alt", "Cachorro");

});


// EXERCÍCIO 5 

console.log(imagem.getAttribute("src"));
console.log(imagem.getAttribute("alt"));



// EXERCÍCIO 6 

const mensagem = document.querySelector("#mensagem");
const botaoMensagem = document.querySelector("#botaoMensagem");


botaoMensagem.addEventListener("click", function() {
    mensagem.textContent = "Você clicou no botão!";

});



// EXERCÍCIO 7

const mensagemBotoes = document.querySelector("#mensagemBotoes");
const btn1 = document.querySelector("#btn1");
const btn2 = document.querySelector("#btn2");
const btn3 = document.querySelector("#btn3");


btn1.addEventListener("click", function() {

    mensagemBotoes.textContent = "Olá, usuário!";

});


btn2.addEventListener("click", function() {
    mensagemBotoes.textContent = "Até mais!";

});


btn3.addEventListener("click", function() {
    mensagemBotoes.textContent = "Estou aprendendo JavaScript!";

});



// EXERCÍCIO 8 - Contador


let numero = 0;


const contador = document.querySelector("#contador");
const diminuir = document.querySelector("#diminuir");
const aumentar = document.querySelector("#aumentar");


aumentar.addEventListener("click", function() {

    numero = numero + 1;
    contador.textContent = numero;

});


diminuir.addEventListener("click", function() {

    numero = numero - 1;

    contador.textContent = numero;

});



// EXERCÍCIO 9 


const quadrado = document.querySelector("#quadrado");


quadrado.addEventListener("mouseenter", function() {
    quadrado.textContent = "O mouse entrou!";

});


quadrado.addEventListener("mouseleave", function() {
    quadrado.textContent = "O mouse saiu!";

});


// EXERCÍCIO 10 

const campo = document.querySelector("#campo");
const resultado = document.querySelector("#resultado");


campo.addEventListener("input", function() {

    resultado.textContent = campo.value;

});