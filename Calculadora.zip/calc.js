const num1 = document.querySelector("#firstNumber");
const num2 = document.querySelector("#secondNumber");
const button = document.querySelector(".button");
const result = document.querySelector(".result");
const operacion = document.querySelector("#operacion");

button.addEventListener("click", function () {

    let calculation;

    switch (operacion.value) {
        case "sum":
            calculation = Number(num1.value) + Number(num2.value);

            break;

        case "subtraction":
            calculation = Number(num1.value) - Number(num2.value);

            break;

        case "multiplication":
            calculation = Number(num1.value) * Number(num2.value);

            break;

        case "division":
            calculation = Number(num1.value) / Number(num2.value);

            break;

    }

    result.textContent = calculation;


});

